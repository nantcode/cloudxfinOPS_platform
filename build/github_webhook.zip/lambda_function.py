import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))
    
    headers = event.get("headers", {})
    github_event = headers.get("x-github-event", "unknown")
    
    # Handle GitHub Ping / Handshake Event
    if github_event == "ping":
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "PONG - Webhook connection successful!"})
        }
        
    # Handle Pull Request Events
    if github_event == "pull_request":
        body = json.loads(event.get("body", "{}"))
        action = body.get("action")
        pr_number = body.get("number")
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": f"PR #{pr_number} event '{action}' processed successfully.",
                "status": "GUARDRAIL_EVALUATION_QUEUED"
            })
        }

    return {
        "statusCode": 200,
        "body": json.dumps({"message": f"Event '{github_event}' received."})
    }
